/**
 * @file student.h
 * @author Christian Canlas (you@domain.com)
 * @brief type def for student
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
 
 /**
  * @brief typedef of struct Student
  * Student has first_name(49 characters), last name(49 characters), id(10 characters)
  * array of grades(double), and number of grades(int)
  */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
