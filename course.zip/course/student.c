/**
 * @file student.c
 * @author Christian Canlas (you@domain.com)
 * @brief Student Function Files
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Takes input of student and grade score and adds the score to the students grades
 * 
 * @param student: Student inputted
 * @param grade: Grade to be added
 */
void add_grade(Student* student, double grade)
{
  /* Increases the number of grades student has. If this is the students first grade calloc
   * is used to create an array with the memory for one grade(double).
   * 
   */
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  // If it isn't the first then dynamic memory reallocation is used to add grade to the student.
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief Takes input of student, and returns the average grade score of the students grades
 * 
 * @param student: Student inputted
 * @return double: The average grade of the grades added to the student
 */
double average(Student* student)
{
  // If the student doesn't have any grades return 0

  if (student->num_grades == 0) return 0;

  /* Takes the grades of the student and divides by the number of grades of student
   * to return the average */
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief Prints the important values of given student
 * (Name, ID, Grades, Average)
 * 
 * @param student: Student to print 
 */
void print_student(Student* student)
{
  //Gets members of Student structure and prints them in formatted way

  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief Returns a random student with a random first and last name, random id
 * and adds the inputed amount of random grades
 * 
 * @param grades: Number of random grades to be added to random student
 * @return Student*: The random student generated
 */
Student* generate_random_student(int grades)
{
 
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  //Takes a random first and last name from the array of preset names
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  // returns a random student id 9 characters long,
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  /* Using the inputted (int grades)
    adds the set amount of random grades from (25-100) */
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}